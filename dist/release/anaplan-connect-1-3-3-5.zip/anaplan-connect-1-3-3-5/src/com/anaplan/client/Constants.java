package com.anaplan.client;

public class Constants {

    /**
     * Part of the path for the password file
     */
    public static final String PASSWORD_FILE_PATH_SEGMENT = ".anaplan/api-client/keystore-access.txt";
    
}
