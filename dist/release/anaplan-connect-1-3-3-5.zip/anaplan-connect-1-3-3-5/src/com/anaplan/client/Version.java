// This file is mechanically generated; Changes should be made in build.xml
package com.anaplan.client;
interface Version {
    static int MAJOR = 1, MINOR = 3;
    static int REVISION = 3;
    static String RELEASE = "-5";
}
